% Monte Carlo Simulation 
%############################################
% Monte Carlo method calculates the value of ?:
% written by: Fahad Mostafa@ Texas Tech,2021
%#########################################################

n = 1000000; % number of samples for  Monte Carlo 
% estimate the domain of input variable and generate samples
x = rand(n, 1); % sample the input random variable x 
y = rand(n, 1); % sample the input random variable y
point_in_circle = (x.^2 + y.^2 < 1); % is the point inside a unit circle?
percentage = sum(point_in_circle) / n; % compute statistics: the inside percentage
Estimation_pi = percentage * 4
